import SwiftUI

struct ContentView: View {

    var body: some View {
            //Progress bar needs to be connected to the task in the list and show the progress.
        Navigationbar()
    }
}
